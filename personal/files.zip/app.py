"""
메인 윈도우 — 프리셋 시스템 + config.json 자동 저장 + 포커스 모니터.

레이아웃:
1. 상단바: 프리셋 드롭다운 + 💾 저장 + Always on Top
2. 입력 소스 패널 (InputPanel)
3. 대상 텍스트 표시
4. 설정 패널 (SettingsPanel)
5. 컨트롤 패널 (ControlPanel)
"""

import customtkinter as ctk

from gui.input_panel import InputPanel
from gui.settings_panel import SettingsPanel
from gui.control_panel import ControlPanel
from core.text_preprocessor import preprocess, PreprocessConfig
from preset_manager import (
    PresetManager, preset_to_configs, configs_to_preset,
    load_app_config, save_app_config,
)


class App(ctk.CTk):
    """Human-Like Typer 메인 윈도우."""

    def __init__(self):
        super().__init__()

        self.title("Human-Like Typer v1.0")
        self.geometry("750x900")
        self.minsize(600, 600)

        # 상태
        self._target_text: str = ""

        # 프리셋 매니저 + config
        self._preset_mgr = PresetManager()
        self._app_config = load_app_config()

        self._build_ui()
        self._load_last_preset()

        # 초기 always on top 적용
        aot = self._app_config.get("window", {}).get("always_on_top", False)
        if aot:
            self._aot_var.set(True)
            self.attributes("-topmost", True)

        self.protocol("WM_DELETE_WINDOW", self._on_closing)

    def _build_ui(self):
        # ── 상단바 ──
        topbar = ctk.CTkFrame(self, height=40)
        topbar.pack(fill="x", padx=10, pady=(8, 4))
        topbar.pack_propagate(False)

        ctk.CTkLabel(
            topbar, text="프리셋:", font=ctk.CTkFont(size=12),
        ).pack(side="left", padx=(8, 4))

        preset_names = self._preset_mgr.list_all_display_names()
        self._preset_dropdown = ctk.CTkOptionMenu(
            topbar,
            values=preset_names if preset_names else ["(없음)"],
            width=200, height=28, font=ctk.CTkFont(size=11),
            command=self._on_preset_selected,
        )
        self._preset_dropdown.pack(side="left", padx=4)

        ctk.CTkButton(
            topbar, text="💾 저장", width=60, height=28,
            font=ctk.CTkFont(size=11),
            command=self._on_save_custom,
        ).pack(side="left", padx=4)

        self._aot_var = ctk.BooleanVar(value=False)
        ctk.CTkSwitch(
            topbar, text="📌 Always on Top",
            variable=self._aot_var, font=ctk.CTkFont(size=11),
            command=self._toggle_always_on_top,
            onvalue=True, offvalue=False, width=40,
        ).pack(side="right", padx=(4, 8))

        # ── 입력 소스 패널 ──
        self._input_panel = InputPanel(
            self, on_text_selected=self._on_text_selected,
        )
        self._input_panel.pack(fill="both", padx=10, pady=4, expand=False)

        # ── 대상 텍스트 표시 ──
        self._target_frame = ctk.CTkFrame(self, height=50)
        self._target_frame.pack(fill="x", padx=10, pady=4)
        self._target_frame.pack_propagate(False)

        self._target_label = ctk.CTkLabel(
            self._target_frame,
            text="대상 텍스트: (설정되지 않음)",
            font=ctk.CTkFont(size=12), text_color="gray", anchor="w",
        )
        self._target_label.pack(fill="x", padx=10, pady=10)

        # ── 설정 패널 ──
        self._settings_panel = SettingsPanel(
            self, on_config_changed=self._on_settings_changed,
        )
        self._settings_panel.pack(fill="both", padx=10, pady=4, expand=True)

        # ── 컨트롤 패널 ──
        self._control_panel = ControlPanel(
            self,
            get_target_text=lambda: self._target_text,
            get_settings=self._get_current_settings,
        )
        self._control_panel.pack(fill="both", padx=10, pady=(4, 8), expand=True)

    # ── 프리셋 ──

    def _load_last_preset(self):
        """앱 시작 시 마지막 사용 프리셋 로드."""
        name = self._app_config.get("last_preset", "default")
        is_custom = self._app_config.get("last_preset_custom", False)
        data = self._preset_mgr.load(name, custom=is_custom)
        if data:
            self._apply_preset(data)
            display = data.get("preset_name", name)
            if is_custom:
                display = f"[커스텀] {display}"
            try:
                self._preset_dropdown.set(display)
            except Exception:
                pass

    def _on_preset_selected(self, display_name: str):
        """프리셋 드롭다운에서 선택."""
        result = self._preset_mgr.find_by_display_name(display_name)
        if result is None:
            return
        name, is_custom = result
        data = self._preset_mgr.load(name, custom=is_custom)
        if data:
            self._apply_preset(data)
            self._app_config["last_preset"] = name
            self._app_config["last_preset_custom"] = is_custom
            save_app_config(self._app_config)

    def _apply_preset(self, data: dict):
        """프리셋 데이터를 설정 패널에 반영."""
        timing, typo, control, prep = preset_to_configs(data)
        self._settings_panel.set_timing_config(timing)
        self._settings_panel.set_typo_config(typo)

        # 고급 탭: 정교 모드
        if control.get("precise_mode", False):
            self._settings_panel._input_mode_var.set("precise")
        else:
            self._settings_panel._input_mode_var.set("simple")

        # 컨트롤 패널: 카운트다운, 포커스 모니터
        countdown = control.get("countdown_seconds", 3)
        self._control_panel.set_countdown(countdown)

        focus = control.get("focus_monitor_enabled", True)
        self._control_panel.set_focus_monitor(focus)

    def _on_save_custom(self):
        """현재 설정을 커스텀 프리셋으로 저장."""
        dialog = ctk.CTkInputDialog(
            text="커스텀 프리셋 이름을 입력하세요:",
            title="프리셋 저장",
        )
        name = dialog.get_input()
        if not name or not name.strip():
            return

        timing = self._settings_panel.get_timing_config()
        typo = self._settings_panel.get_typo_config()
        precise = self._settings_panel.is_precise_mode()
        control = {
            "precise_mode": precise,
            "countdown_seconds": self._control_panel.get_countdown(),
            "focus_monitor_enabled": self._control_panel.get_focus_monitor(),
        }
        prep = self._settings_panel.get_preprocess_config()

        data = configs_to_preset(name.strip(), "사용자 커스텀 프리셋",
                                  timing, typo, control, prep)
        file_name = name.strip().replace(" ", "_")
        self._preset_mgr.save_custom(file_name, data)

        # 드롭다운 갱신
        names = self._preset_mgr.list_all_display_names()
        self._preset_dropdown.configure(values=names)
        self._preset_dropdown.set(f"[커스텀] {name.strip()}")

    # ── 이벤트 핸들러 ──

    def _on_text_selected(self, raw_text: str):
        preprocess_cfg = self._settings_panel.get_preprocess_config()
        text = preprocess(raw_text, preprocess_cfg)
        self._target_text = text

        if text:
            preview = text[:60].replace('\n', '↵')
            suffix = "..." if len(text) > 60 else ""
            self._target_label.configure(
                text=f"대상 텍스트: \"{preview}{suffix}\" ({len(text)}자)",
                text_color=("gray10", "gray90"),
            )
        else:
            self._target_label.configure(
                text="대상 텍스트: (비어있음)", text_color="gray",
            )

    def _toggle_always_on_top(self):
        val = self._aot_var.get()
        self.attributes("-topmost", val)
        self._app_config.setdefault("window", {})["always_on_top"] = val
        save_app_config(self._app_config)

    def _on_settings_changed(self):
        timing = self._settings_panel.get_timing_config()
        self._input_panel.update_base_delay(timing.base_delay_ms)

    def _get_current_settings(self) -> tuple:
        return (
            self._settings_panel.get_timing_config(),
            self._settings_panel.get_typo_config(),
            self._settings_panel.is_precise_mode(),
            self._control_panel.get_focus_monitor(),
        )

    def _on_closing(self):
        save_app_config(self._app_config)
        self._control_panel.destroy()
        self.destroy()
